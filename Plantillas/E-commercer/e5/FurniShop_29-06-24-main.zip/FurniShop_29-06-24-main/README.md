# FurniShop_29-06-24
Learn how to build a fully responsive e-commerce website from scratch using HTML, CSS, and JavaScript!
