# Ecommerce-Website-master
Simple E-commerce website using HTML, CSS and JAVASCRIPT

## UI
![image](https://user-images.githubusercontent.com/105323431/215714209-efbf84ee-6c84-42d0-8108-d413f2a0dd4a.png)
